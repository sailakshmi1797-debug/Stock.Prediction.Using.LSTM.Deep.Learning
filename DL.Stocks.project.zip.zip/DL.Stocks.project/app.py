import streamlit as st
import yfinance as yf
import pandas as pd
import numpy as np
import tensorflow.keras.models
import pickle
import matplotlib.pyplot as plt

# Load your trained model and scaler
model = tensorflow.keras.models.load_model('stock_lstm_model.h5')
scaler = pickle.load(open('scaler.pkl', 'rb'))

st.title('Stock Price Prediction with LSTM')

# Input: Stock ticker
ticker = st.text_input('Enter Stock Ticker (e.g., AAPL, TSLA)', 'AAPL')

if st.button('Predict'):
    # Fetch historical stock data
    data = yf.download(ticker, start='2018-01-01', end='2025-01-01')
    st.subheader('Historical Data')
    st.write(data)

    if data.empty:
        st.error('No data found for this ticker!')
    else:
        # Prepare input for the model
        close_prices = data[['Close']].values
        scaled_data = scaler.transform(close_prices)

        # Create sequences (last 60 days)
        X = []
        for i in range(60, len(scaled_data)):
            X.append(scaled_data[i-60:i, 0])
        X = np.array(X)
        X = X.reshape(X.shape[0], X.shape[1], 1)

        # Make prediction
        predictions = model.predict(X)
        predictions = scaler.inverse_transform(predictions)

        # Show results
        st.subheader('Predicted Stock Prices')
        st.line_chart(pd.DataFrame(predictions, columns=['Predicted Close']))

        # Optionally, you can plot real vs predicted
        st.subheader('Real vs Predicted')
        real_prices = close_prices[60:]  # Align real prices with predictions
        st.line_chart(pd.DataFrame({
            'Real': real_prices.flatten(),
            'Predicted': predictions.flatten()
        }))